# Building NiSen APK

Complete guide to build NiSen as an Android APK.

## Prerequisites

- Node.js v18+ ([download](https://nodejs.org/))
- Either:
  - **Option A:** Expo Account (free) + EAS CLI
  - **Option B:** Android Studio + Android SDK

## Quick Build (Option A - Recommended)

```bash
cd mobile
npm install
npm install -g eas-cli
npx eas login
npx eas build --platform android
```

Download APK from the build URL provided.

## Local Build (Option B)

```bash
cd mobile
npm install
npm run build:android
```

APK at: `android/app/build/outputs/apk/release/app-release.apk`

## Troubleshooting

If dependencies fail:
```bash
npm install --legacy-peer-deps --force
```

For more help, see QUICK_START.md
