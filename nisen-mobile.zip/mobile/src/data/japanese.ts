export type Character = {
  character: string;
  romaji: string;
  type: 'hiragana' | 'katakana';
};

export type KanjiCharacter = {
  character: string;
  meaning: string;
  romaji: string;
  type: 'kanji';
};

export const hiragana: Character[] = [
  { character: 'あ', romaji: 'a', type: 'hiragana' },
  { character: 'い', romaji: 'i', type: 'hiragana' },
  { character: 'う', romaji: 'u', type: 'hiragana' },
  { character: 'え', romaji: 'e', type: 'hiragana' },
  { character: 'お', romaji: 'o', type: 'hiragana' },
  { character: 'か', romaji: 'ka', type: 'hiragana' },
  { character: 'き', romaji: 'ki', type: 'hiragana' },
  { character: 'く', romaji: 'ku', type: 'hiragana' },
  { character: 'け', romaji: 'ke', type: 'hiragana' },
  { character: 'こ', romaji: 'ko', type: 'hiragana' },
];

export const katakana: Character[] = [
  { character: 'ア', romaji: 'a', type: 'katakana' },
  { character: 'イ', romaji: 'i', type: 'katakana' },
  { character: 'ウ', romaji: 'u', type: 'katakana' },
  { character: 'エ', romaji: 'e', type: 'katakana' },
  { character: 'オ', romaji: 'o', type: 'katakana' },
  { character: 'カ', romaji: 'ka', type: 'katakana' },
  { character: 'キ', romaji: 'ki', type: 'katakana' },
  { character: 'ク', romaji: 'ku', type: 'katakana' },
  { character: 'ケ', romaji: 'ke', type: 'katakana' },
  { character: 'コ', romaji: 'ko', type: 'katakana' },
];

export const basicKanji: KanjiCharacter[] = [
  { character: '一', meaning: 'one', romaji: 'ichi', type: 'kanji' },
  { character: '二', meaning: 'two', romaji: 'ni', type: 'kanji' },
  { character: '三', meaning: 'three', romaji: 'san', type: 'kanji' },
  { character: '四', meaning: 'four', romaji: 'shi', type: 'kanji' },
  { character: '五', meaning: 'five', romaji: 'go', type: 'kanji' },
  { character: '六', meaning: 'six', romaji: 'roku', type: 'kanji' },
  { character: '七', meaning: 'seven', romaji: 'shichi', type: 'kanji' },
  { character: '八', meaning: 'eight', romaji: 'hachi', type: 'kanji' },
  { character: '九', meaning: 'nine', romaji: 'kyuu', type: 'kanji' },
  { character: '十', meaning: 'ten', romaji: 'juu', type: 'kanji' },
];
