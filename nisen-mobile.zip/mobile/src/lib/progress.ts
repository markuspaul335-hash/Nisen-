import AsyncStorage from '@react-native-async-storage/async-storage';

export interface ProgressData {
  charactersLearned: Set<string>;
  quizHistory: {
    id: string;
    type: 'hiragana' | 'katakana' | 'kanji';
    score: number;
    totalQuestions: number;
    completedAt: string;
  }[];
  studyDays: {
    date: string;
    charactersReviewed: number;
    quizzesCompleted: number;
  }[];
  currentStreak: number;
  lastStudyDate: string | null;
}

const PROGRESS_KEY = 'japanese_learning_progress';

export async function getProgress(): Promise<ProgressData> {
  try {
    const stored = await AsyncStorage.getItem(PROGRESS_KEY);
    if (!stored) {
      return getDefaultProgress();
    }
    const data = JSON.parse(stored);
    data.charactersLearned = new Set(data.charactersLearned);
    return data;
  } catch {
    return getDefaultProgress();
  }
}

function getDefaultProgress(): ProgressData {
  return {
    charactersLearned: new Set(),
    quizHistory: [],
    studyDays: [],
    currentStreak: 0,
    lastStudyDate: null,
  };
}

export async function saveProgress(progress: ProgressData): Promise<void> {
  try {
    const data = {
      ...progress,
      charactersLearned: Array.from(progress.charactersLearned),
    };
    await AsyncStorage.setItem(PROGRESS_KEY, JSON.stringify(data));
  } catch (error) {
    console.error('Failed to save progress:', error);
  }
}

export async function markCharacterLearned(
  character: string,
  type: 'hiragana' | 'katakana' | 'kanji'
): Promise<void> {
  const progress = await getProgress();
  progress.charactersLearned.add(character);
  updateStudyDay(progress);
  await saveProgress(progress);
}

export async function saveQuizResult(
  type: 'hiragana' | 'katakana' | 'kanji',
  score: number,
  totalQuestions: number
): Promise<void> {
  const progress = await getProgress();

  progress.quizHistory.push({
    id: `${Date.now()}`,
    type,
    score,
    totalQuestions,
    completedAt: new Date().toISOString(),
  });

  updateStudyDayForQuiz(progress);
  await saveProgress(progress);
}

function updateStudyDay(progress: ProgressData): void {
  const today = new Date().toISOString().split('T')[0];
  const existingDay = progress.studyDays.find((d) => d.date === today);

  if (existingDay) {
    existingDay.charactersReviewed += 1;
  } else {
    progress.studyDays.push({
      date: today,
      charactersReviewed: 1,
      quizzesCompleted: 0,
    });
  }

  updateStreak(progress, today);
}

function updateStudyDayForQuiz(progress: ProgressData): void {
  const today = new Date().toISOString().split('T')[0];
  const existingDay = progress.studyDays.find((d) => d.date === today);

  if (existingDay) {
    existingDay.quizzesCompleted += 1;
  } else {
    progress.studyDays.push({
      date: today,
      charactersReviewed: 0,
      quizzesCompleted: 1,
    });
  }

  updateStreak(progress, today);
}

function updateStreak(progress: ProgressData, today: string): void {
  if (!progress.lastStudyDate) {
    progress.currentStreak = 1;
    progress.lastStudyDate = today;
    return;
  }

  if (progress.lastStudyDate === today) {
    return;
  }

  const lastDate = new Date(progress.lastStudyDate);
  const currentDate = new Date(today);
  const diffDays = Math.floor(
    (currentDate.getTime() - lastDate.getTime()) / (1000 * 60 * 60 * 24)
  );

  if (diffDays === 1) {
    progress.currentStreak += 1;
  } else if (diffDays > 1) {
    progress.currentStreak = 1;
  }

  progress.lastStudyDate = today;
}

export async function getTotalCharactersLearned(): Promise<number> {
  const progress = await getProgress();
  return progress.charactersLearned.size;
}

export async function getQuizAccuracy(): Promise<number> {
  const progress = await getProgress();
  if (progress.quizHistory.length === 0) return 0;

  const lastTenQuizzes = progress.quizHistory.slice(-10);
  const totalScore = lastTenQuizzes.reduce((sum, quiz) => sum + quiz.score, 0);
  const totalQuestions = lastTenQuizzes.reduce(
    (sum, quiz) => sum + quiz.totalQuestions,
    0
  );

  return Math.round((totalScore / totalQuestions) * 100);
}

export async function getStudyStreak(): Promise<number> {
  const progress = await getProgress();
  return progress.currentStreak;
}

export async function getModuleProgress(
  type: 'hiragana' | 'katakana' | 'kanji'
): Promise<{ learned: number; total: number; percentage: number }> {
  const progress = await getProgress();
  const charactersOfType = Array.from(progress.charactersLearned).filter(
    (char) => {
      if (type === 'hiragana') {
        return /[\u3040-\u309F]/.test(char);
      } else if (type === 'katakana') {
        return /[\u30A0-\u30FF]/.test(char);
      } else {
        return /[\u4E00-\u9FFF]/.test(char);
      }
    }
  );

  const totals = { hiragana: 46, katakana: 46, kanji: 10 };
  const learned = charactersOfType.length;
  const total = totals[type];
  const percentage = Math.round((learned / total) * 100);

  return { learned, total, percentage };
}
